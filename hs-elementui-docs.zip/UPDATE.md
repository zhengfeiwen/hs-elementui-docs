
#### 版本 : 0.2.61
`日期`2021/01/25  
`作者`zhengfeiwen  
`说明`[tag](#/container/index) 新增容器组件`hs-container`,`hs-header`,`hs-main`,`hs-aside`,`hs-footer`
#### 版本 : 0.2.59
`日期`2021/01/25  
`作者`zhengfeiwen  
`说明`[tag](#/progress/index) 重构组件`hs-progress`
#### 版本 : 0.2.58
`日期`2021/01/25  
`作者`zhengfeiwen  
`说明`[tag](#/tag/index) 新增标签组件`hs-tag`
#### 版本 : 0.2.55
`日期`2021/01/22  
`作者`zhengfeiwen  
`说明`[plupload](#/plupload/index) 新增文件下载组件`hs-plupload`
#### 版本 : 0.2.50
`日期`2021/01/21  
`作者`zhengfeiwen  
`说明`[link](#/link/index) 新增链接按钮组件`hs-link`,并整合了iconbutton，extendbutton，logobutton，原先的弃用
#### 版本 : 0.2.48
`日期`2021/01/18  
`作者`zhengfeiwen  
`说明`[button](#/button/index) 新增按钮组件`hs-button`
#### 版本 : 0.2.45
`日期`2021/01/15  
`作者`zhengfeiwen  
`说明`[layout](#/layout/index) 新增布局组件`hs-row`,`hs-col`
#### 版本 : 0.1.82
`日期`2020/12/11  
`作者`zhengfeiwen  
`说明`[svg-icon](#/icon/index) 新增图标库`hs-svgicon`
#### 版本 : 0.1.79
`日期`2020/12/09  
`作者`zhengfeiwen  
`说明`[hs-extendbutton](#/button/extendbutton/index) 新增按钮`hs-extendbutton`，收起展开用
#### 版本 : 0.1.78
`日期`2020/12/09
`作者`zhengfeiwen  
`说明`[hs-shortstory](#/busifunc/shortstory/index) 新增业务组件`hs-shortstory`
#### 版本 : 0.1.76
`日期`2020/12/09  
`作者`zhengfeiwen  
`说明`[hs-navitem](#/navigation/navitem/index) 新增组件`hs-navitem`
#### 版本 : 0.1.71
`日期`2020/12/09  
`作者`zhengfeiwen  
`说明`[hs-logobutton](#/button/logobutton/index)组件`hs-logobutton` 加入色系
#### 版本 : 0.1.68
`日期`2020/12/09  
`作者`zhengfeiwen  
`说明`[hs-logobutton](#/button/logobutton/index)新增组件`hs-logobutton`
#### 版本 : 0.1.67
`日期`2020/12/09  
`作者`zhengfeiwen  
`说明`[hs-tabs](#/navigation/tabs/index)组件`hs-tabs`新增`btntab`样式
#### 版本 : 0.1.65
`日期`2020/12/09  
`作者`zhengfeiwen  
`说明`[hs-tabs](#/navigation/tabs/index)组件`hs-tabs`新增`toptab`样式
#### 版本 : 0.1.63
`日期`2020/12/08  
`作者`zhengfeiwen  
`说明`[hs-progress](#/progress/index)组件`hs-progress`调整percentage类型，任务完成后关闭计时器
#### 版本 : 0.1.53
`日期`2020/12/07  
`作者`zhengfeiwen  
`说明`[hs-progress](#/progress/index)新增组件`hs-progress`任务链模式
#### 版本 : 0.1.51
`日期`2020/12/07  
`作者`zhengfeiwen  
`说明`[hs-upload](#/upload/index)修改组件`hs-upload`的提交与上传事件
#### 版本 : 0.1.48
`日期`2020/12/07  
`作者`zhengfeiwen  
`说明`添加组件暴露
#### 版本 : 0.1.47
`日期`2020/12/07  
`作者`zhengfeiwen  
`说明`[hs-upload](#/upload/index)，[hs-progress](#/progress/index)添加组件`hs-upload`，`hs-progress`
#### 版本 : 0.1.34
`日期`2020/12/02  
`作者`zhengfeiwen  
`说明`[HsElementui](#/install/index) 创立组件库