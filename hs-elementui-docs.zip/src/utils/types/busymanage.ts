export type Form = {
  [x: string]: any
  busyName: string
  status: string
}