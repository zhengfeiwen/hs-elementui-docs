export default [
  {
    prop: 'conditons',
    desc: '查询条件集合',
    type: 'Array<Obejct>',
    enum: '-',
    default: '-',
    config: true
  }
]
