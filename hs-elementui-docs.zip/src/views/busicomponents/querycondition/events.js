export default [
  {
    prop: 'change',
    desc: '查询条件改变事件，可以利用该组件进行联动操作',
    callback: 'data:String:查询数据集合；key:String:当前发生改变的查询条件id'
  }
]
