#HsQuerycondition查询集组件
该组件将常用的查询条件组件集群在一起，通过配置的方式去统一生成组件

###Default
展示默认`hs-querycondition`，只要在数组`conditions`配置您所需的组件即可

<slot name="defalutDemo"></slot>

<slot name="table"></slot>