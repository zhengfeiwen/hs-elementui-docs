export const events = [
  {
    prop: 'change',
    desc: '切换事件',
    callback: 'state：当前状态'
  }
]
