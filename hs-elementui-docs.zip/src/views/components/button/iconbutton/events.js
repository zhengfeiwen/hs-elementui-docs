export const events = [
  {
    prop: 'handleClick',
    desc: '点击事件',
    callback: 'key：按钮id没有的话为自增长序列'
  }
]
