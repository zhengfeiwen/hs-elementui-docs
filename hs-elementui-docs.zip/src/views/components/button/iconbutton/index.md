#HsIconbutton 图标按钮-参考文字链接[link](#/link/index)
左侧为小图标，右侧为文字的按钮样式

###基本用法

<slot name="default"></slot>

<slot name="table"></slot>