#HsLogobutton logo按钮-参考文字链接[link](#/link/index)
图标为主的标志按钮

###基本用法
<slot name="default"></slot>

##插入任意内容
<slot name="demo1"></slot>

<slot name="table"></slot>