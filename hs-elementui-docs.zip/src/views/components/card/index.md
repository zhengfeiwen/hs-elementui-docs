#HsCard图片
是一款图片展示组件

###基本用法
<slot name="default"></slot>

##阴影配置
<slot name="demo1"></slot>

<slot name="table"></slot>