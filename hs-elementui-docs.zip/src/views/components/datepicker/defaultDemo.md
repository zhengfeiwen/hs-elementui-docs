```
<template>
  <div>
    <hs-date-picker></hs-date-picker>
  </div>
</template>
<script>
  export default {
  }
</script>
```