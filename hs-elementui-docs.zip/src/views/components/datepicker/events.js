export const events = [
  {
    prop: 'change',
    desc: '日期切换事件',
    callback: 'dateVal:String:日期值'
  }
]
