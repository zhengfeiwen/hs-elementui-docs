#HsDivider
是一款区隔内容的分割线。

###基本用法
<slot name="default"></slot>

##设置文案
<slot name="demo1"></slot>

<slot name="table"></slot>