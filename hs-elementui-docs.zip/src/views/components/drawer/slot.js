export const slot = [
  {
    prop: '-',
    desc: 'Drawer 的内容'
  },
  {
    prop: 'title',
    desc: 'Drawer 标题区的内容'
  }
]
