export const events = [
  {
    prop: 'load',
    desc: '图片加载成功触发',
    callback: 'e:Event'
  },
  {
    prop: 'error',
    desc: '图片加载失败触发',
    callback: 'e:Event'
  }
]
