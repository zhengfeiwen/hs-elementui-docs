#HsImage图片
是一款图片展示组件

###基本用法
<slot name="default"></slot>

##加载失败与加载中效果
<slot name="demo1"></slot>

##懒加载模式
<slot name="demo2"></slot>

<slot name="table"></slot>