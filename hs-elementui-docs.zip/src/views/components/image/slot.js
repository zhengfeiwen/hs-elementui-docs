export const slot = [
  {
    prop: 'placeholder',
    desc: '图片未加载的占位内容'
  },
  {
    prop: 'error',
    desc: '加载失败的内容'
  }
]
