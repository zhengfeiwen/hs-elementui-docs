export const events = [
  {
    prop: 'change',
    desc: 'tab切换事件',
    callback: 'id:String'
  }
]
