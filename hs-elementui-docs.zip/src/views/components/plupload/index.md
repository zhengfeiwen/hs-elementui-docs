#HsPlupload 文件上传组件
提供多样化文件上传

###单文件上传

<slot name="default"></slot>

###多文件上传
<slot name="demo1"></slot>

###大文件上传
<slot name="demo2"></slot>

###断点续传
<slot name="demo3"></slot>

###文件秒传
<slot name="demo4"></slot>

###图片上传
<slot name="demo5"></slot>

###拖拽上传
<slot name="demo6"></slot>

###卡片化
<slot name="demo7"></slot>