export const events = [
  {
    prop: 'change',
    desc: '进度改变时候回调函数',
    callback: ''
  }
]
