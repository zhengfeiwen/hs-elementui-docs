export const attributes = [
  {
    prop: 'tinyVal',
    desc: '富文本内容',
    type: 'string',
    enum: '',
    default: ''
  }
]
