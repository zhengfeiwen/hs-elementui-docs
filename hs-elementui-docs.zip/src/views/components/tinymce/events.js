export const events = [
  {
    prop: 'UploadImg',
    desc: '图片保存事件',
    callback: ''
  }
]
