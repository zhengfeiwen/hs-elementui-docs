#HsTinymce富文本组件

###基本用法
<slot name="default"></slot>
###官方中文文档
<a href="http://tinymce.ax-z.cn/" target="_blank"></a>

<slot name="table"></slot>