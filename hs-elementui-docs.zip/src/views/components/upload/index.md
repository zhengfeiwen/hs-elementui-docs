#HsUpload 上传
通过点击或者拖拽上传文件

###点击上传

<slot name="default"></slot>

###用户头像上传
功能2使用`before-upload`限制用户上传的图片格式和大小。
<slot name="demo1"></slot>

###文件缩略图
使用`scoped-slot`去设置缩略图模版。
<slot name="demo2"></slot>

###图片列表缩略图
<slot name="demo3"></slot>

###上传文件列表控制
功能2使用`before-upload`限制用户上传的图片格式和大小。
<slot name="demo4"></slot>

###拖拽上传
<slot name="demo5"></slot>

###手动上传
<slot name="demo6"></slot>


<slot name="table"></slot>