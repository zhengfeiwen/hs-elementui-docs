export const slot = [
  {
    prop: 'trigger',
    desc: '触发文件选择框的内容'
  },
  {
    prop: 'tip',
    desc: '提示说明文字'
  }
]
