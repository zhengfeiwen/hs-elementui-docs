export const events = [
  {
    prop: 'handle',
    desc: 'do something',
    callback: 'arg1:string, arg2:number'
  }
]
