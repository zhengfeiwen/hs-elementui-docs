<template>
  <div class="container">
    otherrule
  </div>
</template>

<script>
export default {

}
</script>

<style lang="scss">
.container{
  width: 100%;
  height: 100%;
  overflow: hidden;
  iframe{
    width: 100%;
    height: 100%;
  }
}
</style>
