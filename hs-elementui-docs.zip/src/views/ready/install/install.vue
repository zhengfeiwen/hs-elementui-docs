<template>
  <div style="margin-top:20px;">
    <install-md></install-md>
  </div>
</template>
<script>
import installMd from './install.md'

export default {
  name: 'install',
  components: { installMd }
}
</script>
